#include "CodeGenerator.h"

CodeGenerator::CodeGenerator(vector<Quadruple> ic, vector<blockItem> bg)
{
    Quardruple_Code = ic;
    block_group = bg;
}
vector<messageTableItem> CodeGenerator::GenerateMessageTable(int block_no)
{
    vector<messageTableItem> gencode_process;
    map<string, pair<int, bool>> message_link;
    for (auto pos = block_group[block_no].end; pos >= block_group[block_no].begin; pos--)
    {
        Quadruple Gen_Code = Quardruple_Code[pos];
        messageTableItem new_table_item;
        new_table_item.no = pos;
        new_table_item.Gen_Code = Gen_Code;
        if (Gen_Code.arg1[0] == 'G' || Gen_Code.arg1[0] == 'V' || Gen_Code.arg1[0] == 'T')
        {
            if (message_link.find(Gen_Code.arg1) == message_link.end())
            {
                if (Gen_Code.arg1[0] == 'G' || find(block_group[block_no].wait_variable.begin(), block_group[block_no].wait_variable.end(), Gen_Code.arg1) != block_group[block_no].wait_variable.end())
                {
                    message_link[Gen_Code.arg1] = pair<int, bool>(INT_MAX, true);
                }
                else
                {
                    message_link[Gen_Code.arg1] = pair<int, bool>(0, false);
                }
            }
            new_table_item.arg1_tag = message_link[Gen_Code.arg1];
            message_link[Gen_Code.arg1] = pair<int, bool>(pos, true);
        }
        if (Gen_Code.arg2[0] == 'G' || Gen_Code.arg2[0] == 'V' || Gen_Code.arg2[0] == 'T')
        {
            if (message_link.find(Gen_Code.arg2) == message_link.end())
            {
                if (Gen_Code.arg2[0] == 'G' || find(block_group[block_no].wait_variable.begin(), block_group[block_no].wait_variable.end(), Gen_Code.arg2) != block_group[block_no].wait_variable.end())
                {
                    message_link[Gen_Code.arg2] = pair<int, bool>(INT_MAX, true);
                }
                else
                {
                    message_link[Gen_Code.arg2] = pair<int, bool>(0, false);
                }
            }
            new_table_item.arg2_tag = message_link[Gen_Code.arg2];
            message_link[Gen_Code.arg2] = pair<int, bool>(pos, true);
        }
        if (Gen_Code.res[0] == 'G' || Gen_Code.res[0] == 'V' || Gen_Code.res[0] == 'T')
        {
            if (message_link.find(Gen_Code.res) == message_link.end())
            {
                if (Gen_Code.res[0] == 'G' || find(block_group[block_no].wait_variable.begin(), block_group[block_no].wait_variable.end(), Gen_Code.res) != block_group[block_no].wait_variable.end())
                {
                    message_link[Gen_Code.res] = pair<int, bool>(INT_MAX, true);
                }
                else
                {
                    message_link[Gen_Code.res] = pair<int, bool>(0, false);
                }
            }
            new_table_item.result_tag = message_link[Gen_Code.res];
            message_link[Gen_Code.res] = pair<int, bool>(0, false);
        }
        gencode_process.push_back(new_table_item);
        MessTableRecord.push_back(new_table_item);
    }
    reverse(gencode_process.begin(), gencode_process.end());
    return gencode_process;
}

void CodeGenerator::ADD_MIPS_Code(string code)
{
    MipsCodes.push_back(code);
    new_code.push_back(code);
}

string CodeGenerator::getREG(string result)
{
    string R;
    bool has_R = false;
    //result本身有寄存器
    if (AVALUE.find(result) != AVALUE.end() && AVALUE[result].size() > 0)
    {
        for (auto i = 0; i < AVALUE[result].size(); i++)
        {
            if (AVALUE[result][i] != "M")
            {
                R = AVALUE[result][i];
                has_R = true;
                break;
            }
        }
    }
    if (!has_R)
    {
        for (map<string, vector<pair<string, int>>>::iterator iter = RVALUE.begin(); iter != RVALUE.end(); iter++)
        {
            if (iter->second.size() == 0)
            {
                R = iter->first;
                return R;
            }
        }
        //choose R which will be used in longest time
        int farthest_R = -1;
        for (map<string, vector<pair<string, int>>>::iterator iter = RVALUE.begin(); iter != RVALUE.end(); iter++)
        {
            int closest_V = INT_MAX;
            for (auto i = 0; i < iter->second.size(); i++)
            {
                if (iter->second[i].second < closest_V)
                    closest_V = iter->second[i].second;
            }
            if (closest_V > farthest_R)
            {
                farthest_R = closest_V;
                R = iter->first;
            }
        }
    }
    for (auto i = 0; i < RVALUE[R].size(); i++)
    {
        string V = RVALUE[R][i].first;
        if (AVALUE[V].size() == 1 && AVALUE[V][0] == R)
        {
            //save variable V
            if (V[0] == 'G')
                ADD_MIPS_Code("sw " + R + "," + DATA + "+" + to_string(stoi(V.substr(1))));
            else if (V[0] == 'V')
                ADD_MIPS_Code("sw " + R + "," + STACK + "+" + to_string(4 + stoi(V.substr(1))) + "($fp)");
            else if (V[0] == 'T')
                ADD_MIPS_Code("sw " + R + "," + TEMP + "+" + to_string(4 * stoi(V.substr(1))));
            else
            {
                throw string("ERROR: 目标代码生成器错误:AVALUE中出现意外的变量名:") + V + string("\n");
            }
        }
        //delete R from AVALUE
        vector<string>::iterator Ritor = find(AVALUE[V].begin(), AVALUE[V].end(), R);
        AVALUE[V].erase(Ritor);
        //add memroy address to AVALUE
        if (find(AVALUE[V].begin(), AVALUE[V].end(), "M") == AVALUE[V].end())
            AVALUE[V].push_back("M");
    }
    //delete all V from RVALUE
    RVALUE[R].clear();
    return R;
}
void CodeGenerator::FreshReg(pair<int, bool> tag, string R, string V, bool value_changed)
{
    if (value_changed || !tag.second)
    {
        for (auto i = 0; i < AVALUE[V].size(); i++)
        {
            if (RVALUE.find(AVALUE[V][i]) != RVALUE.end())
            {
                string opR = AVALUE[V][i];
                for (auto j = 0; j < RVALUE[opR].size(); j++)
                {
                    if (RVALUE[opR][j].first == V)
                    {
                        vector<pair<string, int>>::iterator iter = find(RVALUE[opR].begin(), RVALUE[opR].end(), RVALUE[opR][j]);
                        RVALUE[opR].erase(iter);
                        break;
                    }
                }
            }
        }
        if (tag.second)
        {
            AVALUE[V] = vector<string>{ R };
            RVALUE[R].push_back(pair<string, int>(V, tag.first));
        }
        else
        {
            AVALUE.erase(V);
        }
    }
    else
    {
        bool is_find = false;
        //在R的记录中寻找V
        for (auto i = 0; i < RVALUE[R].size(); i++)
        {
            if (RVALUE[R][i].first == V)
            {
                //找到V后更新V
                is_find = true;
                RVALUE[R][i].second = tag.first;
                break;
            }
        }
        //没找到V添加V
        if (!is_find)
            RVALUE[R].push_back(pair<string, int>(V, tag.first));

        //V是否存在于AVALUE
        if (AVALUE.find(V) == AVALUE.end())
        {
            //V不存在于AVALUE中则新建V
            AVALUE[V] = vector<string>{ R };
        }
        else
        {
            //V在AVALUE中
            if (find(AVALUE[V].begin(), AVALUE[V].end(), R) == AVALUE[V].end())
                //V的记录中没有R则添加R
                AVALUE[V].push_back(R);
        }
    }
}
void CodeGenerator::endBlock()
{
    //基本块处理结束
    for (map<string, vector<string>>::iterator iter = AVALUE.begin(); iter != AVALUE.end(); iter++)
    {
        string V = iter->first;
        //尚未存入内存的变量
        if (find(AVALUE[V].begin(), AVALUE[V].end(), "M") == AVALUE[V].end())
        {
            string R;
            for (auto i = 0; i < AVALUE[V].size(); i++)
            {
                if (AVALUE[V][i] != "M")

                {
                    R = AVALUE[V][i];
                    break;
                }
            }
            if (V[0] == 'G')
                ADD_MIPS_Code("sw " + R + "," + DATA + "+" + to_string(stoi(V.substr(1))));
            else if (V[0] == 'V')
                ADD_MIPS_Code("sw " + R + "," + STACK + "+" + to_string(4 + stoi(V.substr(1))) + "($fp)");
            else if (V[0] == 'T')
                ADD_MIPS_Code("sw " + R + "," + TEMP + "+" + to_string(4 * stoi(V.substr(1))));
            else
            {
                throw string("ERROR: 目标代码生成器错误:AVALUE中出现意外的变量名:") + V + string("\n");
            }
            //AVALUE[V].push_back("M");
        }
    }
    for (map<string, vector<pair<string, int>>>::iterator iter = RVALUE.begin(); iter != RVALUE.end(); iter++)
    {
        iter->second.clear();
    }
    AVALUE.clear();
}
void CodeGenerator::GenerateCode()
{
    ADD_MIPS_Code(".data");
    ADD_MIPS_Code(DATA + ":.space " + BUF_SIZE);
    ADD_MIPS_Code(STACK + ":.space "+ BUF_SIZE);
    ADD_MIPS_Code(TEMP + ":.space " + BUF_SIZE);
    ADD_MIPS_Code(".text");
    ADD_MIPS_Code("j B0");
    ADD_MIPS_Code("B1:");
    ADD_MIPS_Code("nop");
    ADD_MIPS_Code("j B1");
    ADD_MIPS_Code("nop");
    ADD_MIPS_Code("B2:");
    ADD_MIPS_Code("jal Fmain");
    ADD_MIPS_Code("nop");
    ADD_MIPS_Code("break");
    ADD_MIPS_Code("B0:");
    ADD_MIPS_Code("addi $gp,$zero,0");
    ADD_MIPS_Code("addi $fp,$zero,0");
    ADD_MIPS_Code("addi $sp,$zero,4");
    ADD_MIPS_Code("j B2");
    ADD_MIPS_Code("nop");

    for (auto block_no = 0; block_no < block_group.size(); block_no++)
    {
        vector<messageTableItem> MessageTable = GenerateMessageTable(block_no);
        bool j_end = false;
        for (auto i = 0; i < MessageTable.size(); i++)
        {
            new_code.clear();
            Quadruple Gen_Code = MessageTable[i].Gen_Code;
            string Reg_arg1, Reg_arg2;
            if (Gen_Code.arg1 == "" || Gen_Code.op == "=[]")
                Reg_arg1 = "";
            else if (Gen_Code.arg1[0] == '$')
                Reg_arg1 = Gen_Code.arg1;
            else if (Gen_Code.arg1 == "[$sp]")
                Reg_arg1 = STACK + "($sp)";
            else if (Gen_Code.arg1.find_first_not_of("0123456789") == string::npos)
            {
                if (Gen_Code.op == "+")
                    Reg_arg1 = Gen_Code.arg1;
                else
                {
                    ADD_MIPS_Code("addi $t8,$zero," + Gen_Code.arg1);
                    Reg_arg1 = "$t8";
                }
            }
            else if (Gen_Code.arg1[0] == 'G')
            {
                if (AVALUE.find(Gen_Code.arg1) == AVALUE.end())
                {
                    AVALUE[Gen_Code.arg1] = vector<string>{ "M" };
                }
                else if (AVALUE[Gen_Code.arg1].size() == 0)
                {
                    throw string("ERROR: 目标代码生成器错误:找不到") + Gen_Code.arg1 + string("的地址\n");
                }

                if (AVALUE[Gen_Code.arg1].size() == 1 && AVALUE[Gen_Code.arg1][0] == "M")
                {
                    ADD_MIPS_Code("lw $t8," + DATA + "+" + to_string(stoi(Gen_Code.arg1.substr(1))));
                    Reg_arg1 = "$t8";
                }
                else
                {
                    for (auto i = 0; i < AVALUE[Gen_Code.arg1].size(); i++)
                    {
                        if (AVALUE[Gen_Code.arg1][i] != "M")
                            Reg_arg1 = AVALUE[Gen_Code.arg1][i];
                    }
                }
            }
            else if (Gen_Code.arg1[0] == 'V')
            {
                if (AVALUE.find(Gen_Code.arg1) == AVALUE.end())
                {
                    AVALUE[Gen_Code.arg1] = vector<string>{ "M" };
                }
                else if (AVALUE[Gen_Code.arg1].size() == 0)
                {
                    throw string("ERROR: 目标代码生成器错误:找不到") + Gen_Code.arg1 + string("的地址\n");
                }

                if (AVALUE[Gen_Code.arg1].size() == 1 && AVALUE[Gen_Code.arg1][0] == "M")
                {
                    ADD_MIPS_Code("lw $t8," + STACK + "+" + to_string(4 + stoi(Gen_Code.arg1.substr(1))) + "($fp)");
                    Reg_arg1 = "$t8";
                }
                else
                {
                    for (auto i = 0; i < AVALUE[Gen_Code.arg1].size(); i++)
                    {
                        if (AVALUE[Gen_Code.arg1][i] != "M")
                            Reg_arg1 = AVALUE[Gen_Code.arg1][i];
                    }
                }
            }
            else if (Gen_Code.arg1[0] == 'T')
            {
                if (AVALUE.find(Gen_Code.arg1) == AVALUE.end())
                {
                    AVALUE[Gen_Code.arg1] = vector<string>{ "M" };
                }
                else if (AVALUE[Gen_Code.arg1].size() == 0)
                {
                    throw string("ERROR: 目标代码生成器错误:找不到") + Gen_Code.arg1 + string("的地址\n");
                }

                if (AVALUE[Gen_Code.arg1].size() == 1 && AVALUE[Gen_Code.arg1][0] == "M")
                {
                    ADD_MIPS_Code("lw $t8," + TEMP + "+" + to_string(4 * stoi(Gen_Code.arg1.substr(1))));
                    Reg_arg1 = "$t8";
                }
                else
                {
                    for (auto i = 0; i < AVALUE[Gen_Code.arg1].size(); i++)
                    {
                        if (AVALUE[Gen_Code.arg1][i] != "M")
                            Reg_arg1 = AVALUE[Gen_Code.arg1][i];
                    }
                }
            }

            if (Gen_Code.arg2 == "")
                Reg_arg2 = "";
            else if (Gen_Code.arg2[0] == '$')
                Reg_arg2 = Gen_Code.arg2;
            else if (Gen_Code.arg2 == "[$sp]")
                Reg_arg2 = STACK + "($sp)";
            else if (Gen_Code.arg2.find_first_not_of("0123456789") == string::npos)
            {
                if (Gen_Code.op == "+" && !(Reg_arg1.find_first_not_of("0123456789") == string::npos))//不能有两个立即数
                    Reg_arg2 = Gen_Code.arg2;
                else
                {
                    ADD_MIPS_Code("addi $t9,$zero," + Gen_Code.arg2);
                    Reg_arg2 = "$t9";
                }
            }
            else if (Gen_Code.arg2[0] == 'G')
            {
                if (AVALUE.find(Gen_Code.arg2) == AVALUE.end())
                {
                    AVALUE[Gen_Code.arg2] = vector<string>{ "M" };
                }
                else if (AVALUE[Gen_Code.arg2].size() == 0)
                {
                    throw string("ERROR: 目标代码生成器错误:找不到") + Gen_Code.arg2 + string("的地址\n");
                }

                if (AVALUE[Gen_Code.arg2].size() == 1 && AVALUE[Gen_Code.arg2][0] == "M")
                {
                    ADD_MIPS_Code("lw $t9," + DATA + "+" + to_string(stoi(Gen_Code.arg2.substr(1))));
                    Reg_arg2 = "$t9";
                }
                else
                {
                    for (auto i = 0; i < AVALUE[Gen_Code.arg2].size(); i++)
                    {
                        if (AVALUE[Gen_Code.arg2][i] != "M")
                            Reg_arg2 = AVALUE[Gen_Code.arg2][i];
                    }
                }
            }
            else if (Gen_Code.arg2[0] == 'V')
            {
                if (AVALUE.find(Gen_Code.arg2) == AVALUE.end())
                {
                    AVALUE[Gen_Code.arg2] = vector<string>{ "M" };
                }
                else if (AVALUE[Gen_Code.arg2].size() == 0)
                {
                    throw string("ERROR: 目标代码生成器错误:找不到") + Gen_Code.arg2 + string("的地址\n");
                }

                if (AVALUE[Gen_Code.arg2].size() == 1 && AVALUE[Gen_Code.arg2][0] == "M")
                {
                    ADD_MIPS_Code("lw $t9," + STACK + "+" + to_string(4 + stoi(Gen_Code.arg2.substr(1))) + "($fp)");
                    Reg_arg2 = "$t9";
                }
                else
                {
                    for (auto i = 0; i < AVALUE[Gen_Code.arg2].size(); i++)
                    {
                        if (AVALUE[Gen_Code.arg2][i] != "M")
                            Reg_arg2 = AVALUE[Gen_Code.arg2][i];
                    }
                }
            }
            else if (Gen_Code.arg2[0] == 'T')
            {
                if (AVALUE.find(Gen_Code.arg2) == AVALUE.end())
                {
                    AVALUE[Gen_Code.arg2] = vector<string>{ "M" };
                }
                else if (AVALUE[Gen_Code.arg2].size() == 0)
                {
                    throw string("ERROR: 目标代码生成器错误:找不到") + Gen_Code.arg2 + string("的地址\n");
                }

                if (AVALUE[Gen_Code.arg2].size() == 1 && AVALUE[Gen_Code.arg2][0] == "M")
                {
                    ADD_MIPS_Code("lw $t9," + TEMP + "+" + to_string(4 * stoi(Gen_Code.arg2.substr(1))));
                    Reg_arg2 = "$t9";
                }
                else
                {
                    for (auto i = 0; i < AVALUE[Gen_Code.arg2].size(); i++)
                    {
                        if (AVALUE[Gen_Code.arg2][i] != "M")
                            Reg_arg2 = AVALUE[Gen_Code.arg2][i];
                    }
                }
            }

            if (Gen_Code.op[0] == 'F' || Gen_Code.op[0] == 'L')
            {
                ADD_MIPS_Code(Gen_Code.op + ":");
            }
            else if (Gen_Code.op == "nop")
            {
                ADD_MIPS_Code("nop");
            }
            else if (Gen_Code.op == "j")
            {
                j_end = true;
                endBlock();
                ADD_MIPS_Code("j " + Gen_Code.res);
            }
            else if (Gen_Code.op == "jal")
            {
                j_end = true;
                //endBlock();
                ADD_MIPS_Code("jal " + Gen_Code.res);
            }
            else if (Gen_Code.op == "break")
            {
                j_end = true;
                endBlock();
                ADD_MIPS_Code("break");
            }
            else if (Gen_Code.op == "ret")
            {
                j_end = true;
                endBlock();
                ADD_MIPS_Code("jr $ra");
            }
            else if (Gen_Code.op == "jnz")
            {
                j_end = true;
                if (RVALUE.find(Reg_arg1) != RVALUE.end())
                    FreshReg(MessageTable[i].arg1_tag, Reg_arg1, Gen_Code.arg1, false);
                endBlock();
                ADD_MIPS_Code("bne " + Reg_arg1 + ",$zero," + Gen_Code.res);
            }
            else if (Gen_Code.op == "j<")
            {
                j_end = true;
                ADD_MIPS_Code("addi $t8," + Reg_arg1 + ",1");
                ADD_MIPS_Code("sub $t9," + Reg_arg2 + ",$t8");
                if (RVALUE.find(Reg_arg1) != RVALUE.end())
                    FreshReg(MessageTable[i].arg1_tag, Reg_arg1, Gen_Code.arg1, false);
                if (RVALUE.find(Reg_arg2) != RVALUE.end())
                    FreshReg(MessageTable[i].arg2_tag, Reg_arg2, Gen_Code.arg2, false);
                endBlock();
                ADD_MIPS_Code("bgez $t9," + Gen_Code.res);
            }
            else if (Gen_Code.op == "j<=")
            {
                j_end = true;
                ADD_MIPS_Code("sub $t9," + Reg_arg2 + "," + Reg_arg1);
                if (RVALUE.find(Reg_arg1) != RVALUE.end())
                    FreshReg(MessageTable[i].arg1_tag, Reg_arg1, Gen_Code.arg1, false);
                if (RVALUE.find(Reg_arg2) != RVALUE.end())
                    FreshReg(MessageTable[i].arg2_tag, Reg_arg2, Gen_Code.arg2, false);
                endBlock();
                ADD_MIPS_Code("bgez $t9," + Gen_Code.res);
            }
            else if (Gen_Code.op == "j>")
            {
                j_end = true;
                ADD_MIPS_Code("addi $t9," + Reg_arg2 + ",1");
                ADD_MIPS_Code("sub  $t8," + Reg_arg1 + ",$t9");
                if (RVALUE.find(Reg_arg1) != RVALUE.end())
                    FreshReg(MessageTable[i].arg1_tag, Reg_arg1, Gen_Code.arg1, false);
                if (RVALUE.find(Reg_arg2) != RVALUE.end())
                    FreshReg(MessageTable[i].arg2_tag, Reg_arg2, Gen_Code.arg2, false);
                endBlock();
                ADD_MIPS_Code("bgez $t8," + Gen_Code.res);
            }
            else if (Gen_Code.op == "j>=")
            {
                j_end = true;
                ADD_MIPS_Code("sub $t8," + Reg_arg1 + "," + Reg_arg2);
                if (RVALUE.find(Reg_arg1) != RVALUE.end())
                    FreshReg(MessageTable[i].arg1_tag, Reg_arg1, Gen_Code.arg1, false);
                if (RVALUE.find(Reg_arg2) != RVALUE.end())
                    FreshReg(MessageTable[i].arg2_tag, Reg_arg2, Gen_Code.arg2, false);
                endBlock();
                ADD_MIPS_Code("bgez $t8," + Gen_Code.res);
            }
            else if (Gen_Code.op == "j==")
            {
                j_end = true;
                if (RVALUE.find(Reg_arg1) != RVALUE.end())
                    FreshReg(MessageTable[i].arg1_tag, Reg_arg1, Gen_Code.arg1, false);
                if (RVALUE.find(Reg_arg2) != RVALUE.end())
                    FreshReg(MessageTable[i].arg2_tag, Reg_arg2, Gen_Code.arg2, false);
                endBlock();
                ADD_MIPS_Code("beq " + Reg_arg1 + "," + Reg_arg2 + "," + Gen_Code.res);
            }
            else if (Gen_Code.op == "j!=")
            {
                j_end = true;
                if (RVALUE.find(Reg_arg1) != RVALUE.end())
                    FreshReg(MessageTable[i].arg1_tag, Reg_arg1, Gen_Code.arg1, false);
                if (RVALUE.find(Reg_arg2) != RVALUE.end())
                    FreshReg(MessageTable[i].arg2_tag, Reg_arg2, Gen_Code.arg2, false);
                endBlock();
                ADD_MIPS_Code("bne " + Reg_arg1 + "," + Reg_arg2 + "," + Gen_Code.res);
            }
            else if (Gen_Code.op == ":=")
            {
                string R;
                if (Gen_Code.res[0] == '$')
                {
                    R = Gen_Code.res;
                    if (Gen_Code.arg1 == "[$sp]")
                    {
                        ADD_MIPS_Code("lw " + R + "," + Reg_arg1);
                    }
                    else
                    {
                        ADD_MIPS_Code("add " + R + ",$zero," + Reg_arg1);
                    }
                }
                else if (Gen_Code.res == "[$sp]")
                {
                    R = STACK + "($sp)";
                    if (Gen_Code.arg1 == "[$sp]")
                    {
                        throw string("ERROR: 目标代码生成器错误:发生从[$sp]到[$sp]的赋值\n");
                    }
                    else
                    {
                        ADD_MIPS_Code("sw " + Reg_arg1 + "," + R);
                    }
                }
                else
                {
                    R = getREG(Gen_Code.res);
                    if (Gen_Code.arg1 == "[$sp]")
                    {
                        ADD_MIPS_Code("lw " + R + "," + Reg_arg1);
                    }
                    else
                    {
                        ADD_MIPS_Code("add " + R + ",$zero," + Reg_arg1);
                    }
                }
                if (RVALUE.find(R) != RVALUE.end())
                    FreshReg(MessageTable[i].result_tag, R, Gen_Code.res, true);
                if (RVALUE.find(Reg_arg1) != RVALUE.end())
                    FreshReg(MessageTable[i].arg1_tag, Reg_arg1, Gen_Code.arg1, false);
            }
            else if (Gen_Code.op == "[]=")
            {
                string base = Gen_Code.res;
                if (Gen_Code.res[0] == 'G')
                {
                    ADD_MIPS_Code("sll $t9," + Reg_arg2 + ",2");
                    ADD_MIPS_Code("addi $t9,$t9," + base.substr(1));
                    ADD_MIPS_Code("sw " + Reg_arg1 + "," + DATA + "($t9)");
                }
                else if (Gen_Code.res[0] == 'V')
                {
                    ADD_MIPS_Code("sll $t9," + Reg_arg2 + ",2");
                    ADD_MIPS_Code("addi $t9,$t9," + base.substr(1));
                    ADD_MIPS_Code("addi $t9,$t9,4");
                    ADD_MIPS_Code("add $t9,$t9,$fp");
                    ADD_MIPS_Code("sw " + Reg_arg1 + "," + STACK + "($t9)");
                }
                else if (Gen_Code.res[0] == 'T')
                {
                    ADD_MIPS_Code("addi $t9," + Reg_arg2 + "," + base.substr(1));
                    ADD_MIPS_Code("sll $t9,$t9,2");
                    ADD_MIPS_Code("sw " + Reg_arg1 + "," + TEMP + "($t9)");
                }
                else
                {
                    throw string("ERROR: 目标代码生成器错误:[]=的左部result标识符不合法\n");
                }
                if (RVALUE.find(Reg_arg1) != RVALUE.end())
                    FreshReg(MessageTable[i].arg1_tag, Reg_arg1, Gen_Code.arg1, false);
                if (RVALUE.find(Reg_arg2) != RVALUE.end())
                    FreshReg(MessageTable[i].arg2_tag, Reg_arg2, Gen_Code.arg2, false);
            }
            else if (Gen_Code.op == "=[]")
            {
                string R;
                if (Gen_Code.res[0] == '$')
                    R = Gen_Code.res;
                else if (Gen_Code.res == "[$sp]")
                    R = STACK + "($sp)";
                else
                    R = getREG(Gen_Code.res);
                if (Gen_Code.arg1[0] == 'G')
                {
                    ADD_MIPS_Code("sll $t9," + Reg_arg2 + ",2");
                    ADD_MIPS_Code("addi $t9,$t9," + Gen_Code.arg1.substr(1));
                    ADD_MIPS_Code("lw " + R + "," + DATA + "($t9)");
                }
                else if (Gen_Code.arg1[0] == 'V')
                {
                    ADD_MIPS_Code("sll $t9," + Reg_arg2 + ",2");
                    ADD_MIPS_Code("addi $t9,$t9," + Gen_Code.arg1.substr(1));
                    ADD_MIPS_Code("addi $t9,$t9,4");
                    ADD_MIPS_Code("add $t9,$t9,$fp");
                    ADD_MIPS_Code("lw " + R + "," + STACK + "($t9)");
                }
                else if (Gen_Code.arg1[0] == 'T')
                {
                    ADD_MIPS_Code("addi $t9," + Reg_arg2 + "," + Gen_Code.arg1.substr(1));
                    ADD_MIPS_Code("sll $t9,$t9,2");
                    ADD_MIPS_Code("lw " + R + "," + TEMP + "($t9)");
                }
                else
                {
                    //cerr << "ERROR: =[]的右部arg1标识符不合法\n";
                    throw string("ERROR: 目标代码生成器错误:=[]的右部arg1标识符不合法\n");
                }
                if (RVALUE.find(R) != RVALUE.end())
                    FreshReg(MessageTable[i].result_tag, R, Gen_Code.res, true);
                if (RVALUE.find(Reg_arg2) != RVALUE.end())
                    FreshReg(MessageTable[i].arg2_tag, Reg_arg2, Gen_Code.arg2, false);
            }
            else if (Gen_Code.op == "+")
            {
                string R;
                if (Gen_Code.res[0] == '$')
                    R = Gen_Code.res;
                else if (Gen_Code.res == "[$sp]")
                    R = STACK + "($sp)";
                else
                    R = getREG(Gen_Code.res);

                if (Reg_arg1.find_first_not_of("0123456789") == string::npos)
                    ADD_MIPS_Code("addi " + R + "," + Reg_arg2 + "," + Reg_arg1);
                else if (Reg_arg2.find_first_not_of("0123456789") == string::npos)
                    ADD_MIPS_Code("addi " + R + "," + Reg_arg1 + "," + Reg_arg2);
                else
                    ADD_MIPS_Code("add " + R + "," + Reg_arg1 + "," + Reg_arg2);
                if (RVALUE.find(R) != RVALUE.end())
                    FreshReg(MessageTable[i].result_tag, R, Gen_Code.res, true);
                if (RVALUE.find(Reg_arg1) != RVALUE.end())
                    FreshReg(MessageTable[i].arg1_tag, Reg_arg1, Gen_Code.arg1, false);
                if (RVALUE.find(Reg_arg2) != RVALUE.end())
                    FreshReg(MessageTable[i].arg2_tag, Reg_arg2, Gen_Code.arg2, false);
            }
            else if (Gen_Code.op == "-")
            {
                string R;
                if (Gen_Code.res[0] == '$')
                    R = Gen_Code.res;
                else if (Gen_Code.res == "[$sp]")
                    R = STACK + "($sp)";
                else
                    R = getREG(Gen_Code.res);
                ADD_MIPS_Code("sub " + R + "," + Reg_arg1 + "," + Reg_arg2);
                if (RVALUE.find(R) != RVALUE.end())
                    FreshReg(MessageTable[i].result_tag, R, Gen_Code.res, true);
                if (RVALUE.find(Reg_arg1) != RVALUE.end())
                    FreshReg(MessageTable[i].arg1_tag, Reg_arg1, Gen_Code.arg1, false);
                if (RVALUE.find(Reg_arg2) != RVALUE.end())
                    FreshReg(MessageTable[i].arg2_tag, Reg_arg2, Gen_Code.arg2, false);
            }
            else if (Gen_Code.op == "&")
            {
                string R;
                if (Gen_Code.res[0] == '$')
                    R = Gen_Code.res;
                else if (Gen_Code.res == "[$sp]")
                    R = STACK + "($sp)";
                else
                    R = getREG(Gen_Code.res);
                ADD_MIPS_Code("and " + R + "," + Reg_arg1 + "," + Reg_arg2);
                if (RVALUE.find(R) != RVALUE.end())
                    FreshReg(MessageTable[i].result_tag, R, Gen_Code.res, true);
                if (RVALUE.find(Reg_arg1) != RVALUE.end())
                    FreshReg(MessageTable[i].arg1_tag, Reg_arg1, Gen_Code.arg1, false);
                if (RVALUE.find(Reg_arg2) != RVALUE.end())
                    FreshReg(MessageTable[i].arg2_tag, Reg_arg2, Gen_Code.arg2, false);
            }
            else if (Gen_Code.op == "|")
            {
                string R;
                if (Gen_Code.res[0] == '$')
                    R = Gen_Code.res;
                else if (Gen_Code.res == "[$sp]")
                    R = STACK + "($sp)";
                else
                    R = getREG(Gen_Code.res);
                ADD_MIPS_Code("or " + R + "," + Reg_arg1 + "," + Reg_arg2);
                if (RVALUE.find(R) != RVALUE.end())
                    FreshReg(MessageTable[i].result_tag, R, Gen_Code.res, true);
                if (RVALUE.find(Reg_arg1) != RVALUE.end())
                    FreshReg(MessageTable[i].arg1_tag, Reg_arg1, Gen_Code.arg1, false);
                if (RVALUE.find(Reg_arg2) != RVALUE.end())
                    FreshReg(MessageTable[i].arg2_tag, Reg_arg2, Gen_Code.arg2, false);
            }
            else if (Gen_Code.op == "^")
            {
                string R;
                if (Gen_Code.res[0] == '$')
                    R = Gen_Code.res;
                else if (Gen_Code.res == "[$sp]")
                    R = STACK + "($sp)";
                else
                    R = getREG(Gen_Code.res);
                ADD_MIPS_Code("xor " + R + "," + Reg_arg1 + "," + Reg_arg2);
                if (RVALUE.find(R) != RVALUE.end())
                    FreshReg(MessageTable[i].result_tag, R, Gen_Code.res, true);
                if (RVALUE.find(Reg_arg1) != RVALUE.end())
                    FreshReg(MessageTable[i].arg1_tag, Reg_arg1, Gen_Code.arg1, false);
                if (RVALUE.find(Reg_arg2) != RVALUE.end())
                    FreshReg(MessageTable[i].arg2_tag, Reg_arg2, Gen_Code.arg2, false);
            }
            else if (Gen_Code.op == "*")
            {
                string R;
                if (Gen_Code.res[0] == '$')
                    R = Gen_Code.res;
                else if (Gen_Code.res == "[$sp]")
                    R = STACK + "($sp)";
                else
                    R = getREG(Gen_Code.res);
                ADD_MIPS_Code("mul " + R + "," + Reg_arg1 + "," + Reg_arg2);
                if (RVALUE.find(R) != RVALUE.end())
                    FreshReg(MessageTable[i].result_tag, R, Gen_Code.res, true);
                if (RVALUE.find(Reg_arg1) != RVALUE.end())
                    FreshReg(MessageTable[i].arg1_tag, Reg_arg1, Gen_Code.arg1, false);
                if (RVALUE.find(Reg_arg2) != RVALUE.end())
                    FreshReg(MessageTable[i].arg2_tag, Reg_arg2, Gen_Code.arg2, false);
            }
            else if (Gen_Code.op == "/")
            {
                string R;
                if (Gen_Code.res[0] == '$')
                    R = Gen_Code.res;
                else if (Gen_Code.res == "[$sp]")
                    R = STACK + "($sp)";
                else
                    R = getREG(Gen_Code.res);
                ADD_MIPS_Code("div " + Reg_arg1 + "," + Reg_arg2);
                ADD_MIPS_Code("amflo " + R);//Quotient in $lo
                if (RVALUE.find(R) != RVALUE.end())
                    FreshReg(MessageTable[i].result_tag, R, Gen_Code.res, true);
                if (RVALUE.find(Reg_arg1) != RVALUE.end())
                    FreshReg(MessageTable[i].arg1_tag, Reg_arg1, Gen_Code.arg1, false);
                if (RVALUE.find(Reg_arg2) != RVALUE.end())
                    FreshReg(MessageTable[i].arg2_tag, Reg_arg2, Gen_Code.arg2, false);
            }
            else
            {
                //cerr << "ERROR: 非法的中间代码" << Gen_Code.op << '\t' << Gen_Code.arg1 << '\t' << Gen_Code.arg2 << '\t' << Gen_Code.res << "\n";
                //exit(-1);
                throw string("ERROR: 目标代码生成器错误:非法的中间代码") + Gen_Code.op + string(" ") + Gen_Code.arg1 + string(" ") + Gen_Code.arg2 + string(" ") + Gen_Code.res + string("\n");
            }
            AnalyRecord.push_back({ Gen_Code,new_code,RVALUE,AVALUE });
        }
        if (!j_end)
            endBlock();
    }
}

