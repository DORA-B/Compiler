#ifndef CODEGENERATOR_H
#define CODEGENERATOR_H
#include "LR1.h"
#include "DAGOptimizer.h"
#define STACK string("stack")
#define DATA string("data")
#define TEMP string("temp")
#define BUF_SIZE to_string(4 * 512 * 32)

using namespace std;

struct messageTableItem
{
    int no;
    Quadruple Gen_Code;
    pair<int, bool> arg1_tag;
    pair<int, bool> arg2_tag;
    pair<int, bool> result_tag;
};

struct analysisHistoryItem {
    Quadruple Gen_Code;
    vector<string> object_codes;
    map<string, vector<pair<string, int>>> RVALUE;
    map<string, vector<string>> AVALUE;
};

class CodeGenerator
{
private:
    vector<Quadruple> Quardruple_Code; //来自于优化的代码
    vector<blockItem> block_group;     //来自优化的块组
    map<string, vector<pair<string, int>>> RVALUE = { //寄存器描述数组
        {"$t0",vector<pair<string,int>>{}},
        {"$t1",vector<pair<string,int>>{}},
        {"$t2",vector<pair<string,int>>{}},
        {"$t3",vector<pair<string,int>>{}},
        {"$t4",vector<pair<string,int>>{}},
        {"$t5",vector<pair<string,int>>{}},
        {"$t6",vector<pair<string,int>>{}},
        {"$t7",vector<pair<string,int>>{}}
    };

    map<string, vector<string>> AVALUE;  //变量地址描述数组
    vector<string> new_code;
    vector<messageTableItem> GenerateMessageTable(int block_no);
    void ADD_MIPS_Code(string code);
    string getREG(string result);
    void FreshReg(pair<int, bool> tag, string R, string V, bool value_changed);
    void endBlock();
public:
    vector<string> MipsCodes;
    vector<messageTableItem> MessTableRecord;
    vector<analysisHistoryItem> AnalyRecord;
    CodeGenerator(vector<Quadruple> ic, vector<blockItem> bg);
    void GenerateCode();
};

#endif // CODEGENERATOR_H
