#include "DAGOptimizer.h"


OptimizeAnalyzer::OptimizeAnalyzer(map<int, string> nametable, symbolTable* globaltable, vector<Quadruple> semancode)
{
    NameTable = nametable;
    global_table = globaltable;
    Optimise_Quadruple = semancode;
}

//
bool OptimizeAnalyzer::divfunmain()
{
    int main_id = -1;
    int main_offset;
    for (map<int, string>::iterator iter = NameTable.begin(); iter != NameTable.end(); iter++)
    {
        if (iter->second == "main" && main_id == -1)
        {
            main_id = iter->first;
        }
        else if (iter->second == "main" && main_id != -1)
        {
            throw("ERROR: 优化器错误:定义了多个主函数\n");
        }
    }
    if (main_id == -1)
    {
        throw("ERROR: 优化器错误:未定义主函数\n");
    }

    //全局表中找到main函数id
    for (auto i = 0; i < global_table->table.size(); i++)
    {
        if (global_table->table[i].id == main_id)
        {
            main_offset = global_table->table[i].offset;
            break;
        }
    }

    label_map[main_offset] = "Fmain";
    int normal_label_count = 0;
    int function_label_count = 0;

    for (auto i = 0; i < Optimise_Quadruple.size(); i++)
    {
        Quadruple* e = &Optimise_Quadruple[i];
        if (e->op == "jal")
        {
            if (label_map.find(stoi(e->res)) == label_map.end())
                label_map[stoi(e->res)] = "F" + to_string(function_label_count++);
            e->res = label_map[stoi(e->res)];
        }
        else if (e->op[0] == 'j')
        {
            if (label_map.find(stoi(e->res)) == label_map.end())
                label_map[stoi(e->res)] = "L" + to_string(normal_label_count++);
            e->res = label_map[stoi(e->res)];
        }
    }

    vector<Quadruple> newcode;
    for (auto i = 0; i < Optimise_Quadruple.size(); i++)
    {
        Quadruple e = Optimise_Quadruple[i];
        if (label_map.find(i) != label_map.end())
        {
            Quadruple label = { label_map[i],"","","" };
            newcode.push_back(label);
        }
        newcode.push_back(e);
    }
    Optimise_Quadruple = newcode;
    return true;
}

void OptimizeAnalyzer::paritionWhileRet()
{
    //对于while语句的补丁//
    map<string, int> label_loc;
    for (auto pos = 0; pos < Optimise_Quadruple.size(); pos++)
    {
        if (Optimise_Quadruple[pos].op[0] == 'L')
            label_loc[Optimise_Quadruple[pos].op] = pos;
    }

    for (auto i = 0; i < block_group.size(); i++)
    {
        blockItem* e = &block_group[i];
        //如果这个基本块是函数返回块，那么这个基本块内的赋值变量肯定不会被其他函数内语句块所用到
        if (Optimise_Quadruple[e->end].op == "ret")
        {
            e->useless_variable = e->wait_variable;
            e->wait_variable.clear();
        }
        else//这个基本块不发生返回
        {
            vector<string> real_wait_variable;
            //对于while语句的补丁//
            int pos = block_group[i + 1].begin;
            int prepos = pos - 1;
            while (prepos < Optimise_Quadruple.size())
            {
                if (label_loc.find(Optimise_Quadruple[prepos].res) != label_loc.end()\
                    && label_loc[Optimise_Quadruple[prepos].res] < pos)
                {
                    pos = label_loc[Optimise_Quadruple[prepos].res];
                    prepos = label_loc[Optimise_Quadruple[prepos].res];
                }
                prepos++;
            }

            while (pos < Optimise_Quadruple.size() && Optimise_Quadruple[pos].op[0] != 'F')
            {
                if (find(e->wait_variable.begin(), e->wait_variable.end(), Optimise_Quadruple[pos].arg1) != e->wait_variable.end() && find(real_wait_variable.begin(), real_wait_variable.end(), Optimise_Quadruple[pos].arg1) == real_wait_variable.end())
                {
                    real_wait_variable.push_back(Optimise_Quadruple[pos].arg1);
                }
                if (find(e->wait_variable.begin(), e->wait_variable.end(), Optimise_Quadruple[pos].arg2) != e->wait_variable.end() && find(real_wait_variable.begin(), real_wait_variable.end(), Optimise_Quadruple[pos].arg2) == real_wait_variable.end())
                {
                    real_wait_variable.push_back(Optimise_Quadruple[pos].arg2);
                }
                pos++;
            }
            for (auto j = 0; j < e->wait_variable.size(); j++)
            {
                if (find(real_wait_variable.begin(), real_wait_variable.end(), e->wait_variable[j]) == real_wait_variable.end())
                {
                    e->useless_variable.push_back(e->wait_variable[j]);
                }
            }
            e->wait_variable = real_wait_variable;
        }
    }
}


void OptimizeAnalyzer::partition()
{
    blockItem block;
    for (auto i = 0; i < Optimise_Quadruple.size(); i++)
    {
        Quadruple e = Optimise_Quadruple[i];
        bool jmp_flag = (i - 1 >= 0 && (Optimise_Quadruple[i - 1].op[0] == 'j' || Optimise_Quadruple[i - 1].op == "ret"));
        if (i == 0 || e.op[0] == 'L' || e.op[0] == 'F' || jmp_flag)
        {
            block.begin = i;
            block.wait_variable.clear();
            block.active_variable.clear();
        }
        if ((e.res[0] == 'V' || e.res[0] == 'T') && find(block.wait_variable.begin(), block.wait_variable.end(), e.res) == block.wait_variable.end())
        {
            block.wait_variable.push_back(e.res);
        }
        if ((e.arg1[0] == 'V' || e.arg1[0] == 'T') && find(block.wait_variable.begin(), block.wait_variable.end(), e.arg1) == block.wait_variable.end())
        {
            block.wait_variable.push_back(e.arg1);
        }
        if ((e.arg2[0] == 'V' || e.arg2[0] == 'T') && find(block.wait_variable.begin(), block.wait_variable.end(), e.arg2) == block.wait_variable.end())
        {
            block.wait_variable.push_back(e.arg2);
        }
        if ((e.arg1[0] == 'V' || e.arg1[0] == 'T') && find(block.active_variable.begin(), block.active_variable.end(), e.arg1) == block.active_variable.end())
        {
            block.active_variable.push_back(e.arg1);
        }
        if ((e.arg2[0] == 'V' || e.arg2[0] == 'T') && find(block.active_variable.begin(), block.active_variable.end(), e.arg2) == block.active_variable.end())
        {
            block.active_variable.push_back(e.arg2);
        }
        bool enter_flag = ((i + 1 < Optimise_Quadruple.size() && (Optimise_Quadruple[i + 1].op[0] == 'L' || Optimise_Quadruple[i + 1].op[0] == 'F')) || e.op[0] == 'j' || e.op == "ret" || e.op == "break");
        if (enter_flag)
        {
            block.end = i;
            block_group.push_back(block);
        }
    }

    this->paritionWhileRet();
}

vector<DAGNODE> OptimizeAnalyzer::GenerateDAG(int block_no)
{
    vector<DAGNODE> DAG;
    blockItem* block = &block_group[block_no];
    for (auto pos = block->begin; pos <= block->end; pos++)
    {
        string op = Optimise_Quadruple[pos].op;
        string B = Optimise_Quadruple[pos].arg1;
        string C = Optimise_Quadruple[pos].arg2;
        string A = Optimise_Quadruple[pos].res;
        int element_count;
        if (op == "nop" || op[0] == 'F' || op[0] == 'L') element_count = -1;
        else if (A[0] == '$' || A == "[$sp]") element_count = -1;
        else if (op == ":=") element_count = 0;
        else if (op == "=[]") element_count = 2;
        else if (op == "[]=") element_count = 3;
        else if (op == "j<" || op == "j<=" || op == "j>" || op == "j>=" || op == "j==" || op == "j!=") element_count = -1;
        else if (op == "jnz") element_count = -1;
        else if (op == "j" || op == "jal" || op == "break" || op == "ret") element_count = -1;
        else element_count = 2;

        //不做DAG转化的中间代码
        if (element_count == -1)
        {
            DAGNODE newDAG;
            newDAG.isremain = true;
            newDAG.code = Optimise_Quadruple[pos];
            DAG.push_back(newDAG);
            //保证每一个叶结点都有值，过期的值前面加-，防止再次被选为源操作数
            if (A[0] == '$' || A == "[$sp]")
            {
                for (auto i = 0; i < DAG.size(); i++)
                {
                    if (DAG[i].isleaf && DAG[i].value == A)
                    {
                        DAG[i].value = "-" + A;
                        break;
                    }
                }
            }
            continue;
        }
        //对该中间代码生成DAG
        int state = 1;
        int n;
        int A_no;
        bool new_A;
        int B_no;
        bool new_B;
        int C_no;
        bool new_C;
        while (state > 0)
        {
            switch (state)
            {
                case 1:
                {
                    //在已有DAG节点中寻找B
                    B_no = -1;
                    for (auto i = 0; i < DAG.size(); i++)
                    {
                        if ((DAG[i].isleaf && DAG[i].value == B) || find(DAG[i].tag.begin(), DAG[i].tag.end(), B) != DAG[i].tag.end())
                        {
                            B_no = i;
                            new_B = false;
                            break;
                        }
                    }
                    //已有DAG中没有B则新建B的DAG节点
                    if (B_no == -1)
                    {
                        DAGNODE newDAG;
                        newDAG.isleaf = true;
                        newDAG.value = B;
                        B_no = DAG.size();
                        new_B = true;
                        DAG.push_back(newDAG);
                    }
                    if (element_count == 0)
                    {
                        n = B_no;
                        state = 4;
                    }
                    else if (element_count == 1)
                    {
                        state = 21;
                    }
                    else if (element_count == 2)
                    {
                        //在已有DAG节点中寻找C
                        C_no = -1;
                        for (auto i = 0; i < DAG.size(); i++)
                        {
                            if ((DAG[i].isleaf && DAG[i].value == C) || find(DAG[i].tag.begin(), DAG[i].tag.end(), C) != DAG[i].tag.end())
                            {
                                C_no = i;
                                new_C = false;
                                break;
                            }
                        }
                        //已有DAG中没有C则新建C的DAG节点
                        if (C_no == -1)
                        {
                            DAGNODE newDAG;
                            newDAG.isleaf = true;
                            newDAG.value = C;
                            C_no = DAG.size();
                            new_C = true;
                            DAG.push_back(newDAG);
                        }
                        state = 22;
                    }
                    else if (element_count == 3)
                    {
                        //在已有DAG节点中寻找C
                        C_no = -1;
                        for (auto i = 0; i < DAG.size(); i++)
                        {
                            if ((DAG[i].isleaf && DAG[i].value == C) || find(DAG[i].tag.begin(), DAG[i].tag.end(), C) != DAG[i].tag.end())
                            {
                                C_no = i;
                                new_C = false;
                                break;
                            }
                        }
                        //已有DAG中没有C则新建C的DAG节点
                        if (C_no == -1)
                        {
                            DAGNODE newDAG;
                            newDAG.isleaf = true;
                            newDAG.value = C;
                            C_no = DAG.size();
                            new_C = true;
                            DAG.push_back(newDAG);
                        }
                        //在已有DAG节点中寻找A
                        A_no = -1;
                        for (auto i = 0; i < DAG.size(); i++)
                        {
                            if ((DAG[i].isleaf && DAG[i].value == A) || find(DAG[i].tag.begin(), DAG[i].tag.end(), A) != DAG[i].tag.end())
                            {
                                A_no = i;
                                new_A = false;
                                break;
                            }
                        }
                        //已有DAG中没有A则新建A的DAG节点
                        if (A_no == -1)
                        {
                            DAGNODE newDAG;
                            newDAG.isleaf = true;
                            newDAG.value = A;
                            A_no = DAG.size();
                            new_A = true;
                            DAG.push_back(newDAG);
                        }
                        DAGNODE newDAG;
                        newDAG.isleaf = false;
                        newDAG.op = op;
                        newDAG.left_child = B_no;
                        newDAG.right_child = C_no;
                        newDAG.mid_child = A_no;
                        n = DAG.size();
                        DAG.push_back(newDAG);
                        DAG[B_no].parent = n;
                        DAG[C_no].parent = n;
                        DAG[A_no].parent = n;
                        //其他值为该数组中任意元素的叶结点失效
                        for (auto i = 0; i < DAG.size(); i++)
                        {
                            if (DAG[i].isleaf && DAG[i].value == A)
                            {
                                DAG[i].value = "-" + A;
                                break;
                            }
                        }
                        state = -1;
                    }
                    else
                    {
                        state = -1;
                    }
                    break;
                }
                case 21:
                {
                    if (DAG[B_no].isleaf && (DAG[B_no].value.find_first_not_of("0123456789") == string::npos))
                    {
                        //B是立即数
                        state = 23;
                    }
                    else
                    {
                        state = 31;
                    }
                    break;
                }
                case 22:
                {
                    if ((DAG[B_no].isleaf && (DAG[B_no].value.find_first_not_of("0123456789") == string::npos)) && (DAG[C_no].isleaf && (DAG[C_no].value.find_first_not_of("0123456789") == string::npos)))
                    {
                        //B和C是立即数
                        state = 24;
                    }
                    else
                    {
                        state = 32;
                    }
                    break;
                }
                case 23:
                {
                    //实际上不存在单目运算
                    state = -1;
                    break;
                }
                case 24:
                {
                    int B = stoi(DAG[B_no].value);
                    int C = stoi(DAG[C_no].value);
                    int P;
                    if (op == "+")
                    {
                        P = B + C;
                    }
                    else if (op == "-")
                    {
                        P = B - C;
                    }
                    else if (op == "&")
                    {
                        P = B & C;
                    }
                    else if (op == "|")
                    {
                        P = B | C;
                    }
                    else if (op == "^")
                    {
                        P = B ^ C;
                    }
                    else if (op == "*")
                    {
                        P = B * C;
                    }
                    else if (op == "/")
                    {
                        P = B / C;
                    }
                    DAGNODE tmpB = DAG[B_no], tmpC = DAG[C_no];
                    //如果B是新建的则无需新建B的DAG节点
                    if (new_B)
                    {
                        vector<DAGNODE>::iterator i;
                        i = find(DAG.begin(), DAG.end(), tmpB);
                        DAG.erase(i);
                    }
                    //如果C是新建的则无需新建C的DAG节点
                    if (new_C)
                    {
                        vector<DAGNODE>::iterator i;
                        i = find(DAG.begin(), DAG.end(), tmpC);
                        DAG.erase(i);
                    }
                    //寻找计算结果是否已经有DAG节点
                    n = -1;
                    for (auto i = 0; i < DAG.size(); i++)
                    {
                        if ((DAG[i].isleaf && DAG[i].value == to_string(P)) || find(DAG[i].tag.begin(), DAG[i].tag.end(), to_string(P)) != DAG[i].tag.end())
                        {
                            n = i;
                            break;
                        }
                    }
                    //否则新建计算结果的叶节点
                    if (n == -1)
                    {
                        DAGNODE newDAG;
                        newDAG.isleaf = true;
                        newDAG.value = to_string(P);
                        n = DAG.size();
                        DAG.push_back(newDAG);
                    }
                    state = 4;
                    break;
                }
                case 31:
                {
                    //寻找是否有相同运算的DAG
                    n = -1;
                    for (auto i = 0; i < DAG.size(); i++)
                    {
                        if (!DAG[i].isleaf && DAG[i].left_child == B_no && DAG[i].op == op)
                        {
                            n = i;
                            break;
                        }
                    }
                    //没有则新建根节点
                    if (n == -1)
                    {
                        DAGNODE newDAG;
                        newDAG.isleaf = false;
                        newDAG.op = op;
                        newDAG.left_child = B_no;
                        n = DAG.size();
                        DAG.push_back(newDAG);
                        DAG[B_no].parent = n;
                    }
                    state = 4;
                    break;
                }
                case 32:
                {
                    //寻找是否有相同运算的DAG
                    n = -1;
                    for (auto i = 0; i < DAG.size(); i++)
                    {
                        if (!DAG[i].isleaf && DAG[i].left_child == B_no && DAG[i].right_child == C_no && DAG[i].op == op)
                        {
                            n = i;
                            break;
                        }
                    }
                    //没有则新建根节点
                    if (n == -1)
                    {
                        DAGNODE newDAG;
                        newDAG.isleaf = false;
                        newDAG.op = op;
                        newDAG.left_child = B_no;
                        newDAG.right_child = C_no;
                        n = DAG.size();
                        DAG.push_back(newDAG);
                        DAG[B_no].parent = n;
                        DAG[C_no].parent = n;
                    }
                    state = 4;
                    break;
                }
                case 4:
                {
                    //如果A已经有DAG节点则从这些节点中去除A,但要保证每一个叶结点都有值，过期的值前面加-，防止再次被选为源操作数
                    for (auto i = 0; i < DAG.size(); i++)
                    {
                        if (DAG[i].isleaf && DAG[i].value == A)
                        {
                            DAG[i].value = "-" + A;
                            break;
                        }
                        else if (find(DAG[i].tag.begin(), DAG[i].tag.end(), A) != DAG[i].tag.end())
                        {
                            vector<string>::iterator iter;
                            iter = find(DAG[i].tag.begin(), DAG[i].tag.end(), A);
                            DAG[i].tag.erase(iter);
                            break;
                        }
                    }
                    DAG[n].tag.push_back(A);
                    state = -1;
                    break;
                }
                default:
                    break;
            }
        }
    }
    return DAG;
}


void OptimizeAnalyzer::ActiveNode(vector<DAGNODE>& DAG, int now)
{
    DAG[now].useful = true;
    if (!DAG[now].isleaf)
    {
        if (DAG[now].right_child != -1)
            ActiveNode(DAG, DAG[now].right_child);
        if (DAG[now].left_child != -1)
            ActiveNode(DAG, DAG[now].left_child);
        if (DAG[now].mid_child != -1)
            ActiveNode(DAG, DAG[now].mid_child);
    }
}

string OptimizeAnalyzer::newtag()
{
    return string("S") + to_string(temp_counter++);
}

void OptimizeAnalyzer::optimize()
{
    vector<Quadruple> optimized_code;
    for (int block_no = 0; block_no < block_group.size(); block_no++)
    {
        vector<DAGNODE> DAG = GenerateDAG(block_no);
        DAG_group.push_back(DAG);
        blockItem newblock;
        newblock.begin = optimized_code.size();
        blockItem block = block_group[block_no];
        vector<string> wait_variable = block.wait_variable;
        wait_variable.push_back("$gp");
        wait_variable.push_back("$sp");
        wait_variable.push_back("$fp");
        wait_variable.push_back("$v0");
        wait_variable.push_back("$t0");
        wait_variable.push_back("$t1");
        wait_variable.push_back("$t2");
        wait_variable.push_back("$t3");
        wait_variable.push_back("$t4");
        wait_variable.push_back("$t5");
        wait_variable.push_back("$t6");
        wait_variable.push_back("$t7");
        wait_variable.push_back("[$sp]");
        for (auto i = 0; i < DAG.size(); i++)
        {
            if (DAG[i].isremain)
            {
                if (DAG[i].code.arg1 != "" && find(wait_variable.begin(), wait_variable.end(), DAG[i].code.arg1) == wait_variable.end())
                    wait_variable.push_back(DAG[i].code.arg1);
                if (DAG[i].code.arg2 != "" && find(wait_variable.begin(), wait_variable.end(), DAG[i].code.arg2) == wait_variable.end())
                    wait_variable.push_back(DAG[i].code.arg2);
            }
        }
        for (auto i = 0; i < DAG.size(); i++)
        {
            if (!DAG[i].isremain)
            {
                if (DAG[i].mid_child == -1)
                {
                    vector<string> new_label;
                    for (auto j = 0; j < DAG[i].tag.size(); j++)
                    {
                        if (DAG[i].tag[j][0] == 'G' || find(wait_variable.begin(), wait_variable.end(), DAG[i].tag[j]) != wait_variable.end())
                        {
                            new_label.push_back(DAG[i].tag[j]);
                            DAG[i].useful = true;
                        }
                    }
                    DAG[i].tag = new_label;
                    if (DAG[i].useful)
                        ActiveNode(DAG, i);
                    if (!DAG[i].isleaf && DAG[i].tag.size() == 0)
                        DAG[i].tag.push_back(newtag());
                }
                else
                {
                    DAG[i].useful = true;
                    ActiveNode(DAG, i);
                }
            }
        }
        for (auto i = 0; i < DAG.size(); i++)
        {
            if (DAG[i].isremain)
                optimized_code.push_back(DAG[i].code);
            else
            {
                if (DAG[i].isleaf)
                {
                    for (auto j = 0; j < DAG[i].tag.size(); j++)
                    {
                        string v;
                        if (DAG[i].value[0] == '-')
                            v = DAG[i].value.substr(1);
                        else
                            v = DAG[i].value;
                        Quadruple newTAS = { ":=",v,"",DAG[i].tag[j] };
                        optimized_code.push_back(newTAS);
                    }
                }
                else
                {
                    string lv;
                    if (DAG[DAG[i].left_child].isleaf)
                    {
                        if (DAG[DAG[i].left_child].value[0] == '-')
                            lv = DAG[DAG[i].left_child].value.substr(1);
                        else
                            lv = DAG[DAG[i].left_child].value;
                    }
                    else
                    {
                        lv = DAG[DAG[i].left_child].tag[0];
                    }
                    string rv;
                    if (DAG[DAG[i].right_child].isleaf)
                    {
                        if (DAG[DAG[i].right_child].value[0] == '-')
                            rv = DAG[DAG[i].right_child].value.substr(1);
                        else
                            rv = DAG[DAG[i].right_child].value;
                    }
                    else
                    {
                        rv = DAG[DAG[i].right_child].tag[0];
                    }

                    if (DAG[i].mid_child != -1)
                    {
                        string tri_v;
                        if (DAG[DAG[i].mid_child].isleaf)
                        {
                            if (DAG[DAG[i].mid_child].value[0] == '-')
                                tri_v = DAG[DAG[i].mid_child].value.substr(1);
                            else
                                tri_v = DAG[DAG[i].mid_child].value;
                        }
                        else
                        {
                            tri_v = DAG[DAG[i].mid_child].tag[0];
                        }
                        Quadruple newTAS = { DAG[i].op,lv,rv,tri_v };
                        optimized_code.push_back(newTAS);
                    }
                    else
                    {
                        Quadruple newTAS = { DAG[i].op,lv,rv,DAG[i].tag[0] };
                        optimized_code.push_back(newTAS);
                        for (auto label_no = 1; label_no < DAG[i].tag.size(); label_no++)
                        {
                            Quadruple newTAS = { ":=",DAG[i].tag[0],"",DAG[i].tag[label_no] };
                            optimized_code.push_back(newTAS);
                        }
                    }
                }
            }
        }
        for (auto i = newblock.begin; i < optimized_code.size(); i++)
        {
            Quadruple e = optimized_code[i];
            if (e.op == "+" && e.arg1 == "$sp" && (e.arg2.find_first_not_of("0123456789") == string::npos) && e.res == "$sp")
            {
                int sum = atoi(e.arg2.c_str());
                while (i + 1 < optimized_code.size() && optimized_code[i + 1].op == "+" && optimized_code[i + 1].arg1 == "$sp" && (optimized_code[i + 1].arg2.find_first_not_of("0123456789") == string::npos) && optimized_code[i + 1].res == "$sp")
                {
                    sum += atoi(optimized_code[i + 1].arg2.c_str());
                    optimized_code.erase(optimized_code.begin() + i + 1);
                }
                optimized_code[i].arg2 = to_string(sum);
            }
        }
        newblock.end = optimized_code.size() - 1;
    }
    map<string, string> tmpV_map;
    int newtemp_counter = 0;
    for (auto pos = 0; pos < optimized_code.size(); pos++)
    {
        Quadruple Gen_Code = optimized_code[pos];
        if ((Gen_Code.arg1[0] == 'T' || Gen_Code.arg1[0] == 'S') && tmpV_map.find(Gen_Code.arg1) == tmpV_map.end())
            tmpV_map[Gen_Code.arg1] = "T" + to_string(newtemp_counter++);
        if ((Gen_Code.arg2[0] == 'T' || Gen_Code.arg2[0] == 'S') && tmpV_map.find(Gen_Code.arg2) == tmpV_map.end())
            tmpV_map[Gen_Code.arg2] = "T" + to_string(newtemp_counter++);
        if ((Gen_Code.res[0] == 'T' || Gen_Code.res[0] == 'S') && tmpV_map.find(Gen_Code.res) == tmpV_map.end())
            tmpV_map[Gen_Code.res] = "T" + to_string(newtemp_counter++);
    }
    for (auto pos = 0; pos < optimized_code.size(); pos++)
    {
        Quadruple* pTAS = &optimized_code[pos];
        if (tmpV_map.find(pTAS->arg1) != tmpV_map.end())
            pTAS->arg1 = tmpV_map[pTAS->arg1];
        if (tmpV_map.find(pTAS->arg2) != tmpV_map.end())
            pTAS->arg2 = tmpV_map[pTAS->arg2];
        if (tmpV_map.find(pTAS->res) != tmpV_map.end())
            pTAS->res = tmpV_map[pTAS->res];
    }
    RecordCode = Optimise_Quadruple;
    block_group.clear();
    Optimise_Quadruple = optimized_code;
    partition();
}


int OptimizeAnalyzer::analysis()
{
    divfunmain();
    //showIntermediateCode();
    partition();
    //showBlockGroup();
    int route = 0;
    int original_size = Optimise_Quadruple.size();
    int optimize_size = 0;
    do
    {
        optimize();
        route++;
    } while (RecordCode.size() != Optimise_Quadruple.size());
    optimize_size = Optimise_Quadruple.size();
    cout << "一共优化了" << route << "轮\n";
    cout << "优化率" << 100.0 * double(optimize_size) / double(original_size) << "%\n";
    //showDAG();
    //showIntermediateCode();
    //showBlockGroup();
    return original_size- optimize_size;
}
