#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include "LR1.h"
#include "DAGOptimizer.h"
#include "CodeGenerator.h"
#include "form.h"
#include "ui_mainwindow.h"
#include "qwaitingdialog.h"
#include <QMainWindow>
#include <QFileDialog>
#include <QMessageBox>
#include <QFuture>
#include <QtConcurrent/QtConcurrent>
const QString Linpath  ="lexinput.txt"; //前声明，用于default，实际上强制要求用户指定
const QString Ginpath  ="grainput.txt";
const QString Loutpath  ="lexoutput.txt";
const QString Goutpath  ="ActionGotoTable.txt";
const QString Treepath  ="tree.dot";
const QString Processpath="process.txt";
const QString Semansticpath="semanresult.txt";
const QString CodeGenpath = "CodeGenMips.s";

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT    
public:
    MainWindow(QWidget *parent = nullptr);    
    ~MainWindow();
    LR1 *LR1ANA; //LR1分析器
    OptimizeAnalyzer * DAGOptimizer;
    CodeGenerator * MipsCode;
    QString Lexinputpath;
    QString Grainputpath;
    QString Lexoutpath  ;
    QString Graoutpath  ;
    QString treepath  ;
    QString processpath;
    QString outpath;
    QString semanpath;
    QString mipscodepath;

    bool lexisok;
    bool graisok;
    bool outisok;
    bool lexanaok;
    bool graanaok;
    int code_dec; //优化代码条数
private slots:

    //进行词法分析
    void on_pbt_lex_clicked();
    void on_pbt_gra_clicked();

    //目录文件的选择
    void on_actionIntroduction_triggered();
    void on_action_gra_triggered();
    void on_action_output_triggered();
    void on_action_lex_triggered();
private:
    Ui::MainWindow *ui;
    bool Process_circle();
    void filetoText(const QString filePath,QTextBrowser * towhere);
    void PrintOptimizeCode(const int dec_line); //显示优化后的代码，并显示减少的四元式代码数量
    void PrintActive();    //待用活跃信息表的显示、寄存器信息表
    void PrintReg();      //显示寄存器信息
    void PrintMipsCode(const QString filePath);//显示生成的Mips代码，并储存
};
#endif // MAINWINDOW_H
