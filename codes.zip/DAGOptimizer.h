#ifndef DAGOPETIMIZER_H
#define DAGOPETIMIZER_H
#include"LR1.h"
struct blockItem
{
    int begin;
    int end;
    vector<string> wait_variable;   //待用
    vector<string> useless_variable;//无用
    vector<string> active_variable; //活跃
};

struct DAGNODE
{
    string value;
    string op;
    vector<string> tag;  //标识符，存储别名等
    int parent = -1;
    int left_child = -1;
    int right_child = -1;
    int mid_child = -1;
    bool isremain = false;
    bool useful = false;
    bool isleaf;
    Quadruple code;
    bool operator== (DAGNODE item)
    {
        bool con1 = (this->isleaf == item.isleaf)&&(this->value == item.value)
            && (this->op == item.op) && this->tag.size() == item.tag.size()
            && (this->parent == item.parent) && (this->left_child == item.left_child)&& (this->right_child == item.right_child);
        bool con2 = true;
        for (auto i = 0; i < this->tag.size() && i < item.tag.size(); i++)
        {
            if (this->tag[i] != item.tag[i])
            {
                con2 = false;
                break;
            }
        }
        return con1 && con2;
    }
};

class OptimizeAnalyzer
{
private:
    map<int, string> NameTable;  //存储LexAna的结果NameTable
    symbolTable* global_table;   //存储语义分析的结果全局表
    map<int, string> label_map;	 //
    int temp_counter = 0;
    vector<vector<DAGNODE>> DAG_group;
    vector<Quadruple> RecordCode;  //记录优化时的代码，由此判断是否优化结束
    string newtag();
    bool divfunmain(); //分割出main函数的部分
    void paritionWhileRet();
    void partition();
    void optimize();
    vector<DAGNODE> GenerateDAG(int block_no);
    void ActiveNode(vector<DAGNODE>& DAG, int now);  //使所有节点都变为useful=ture使用状态
public:
    vector<Quadruple> Optimise_Quadruple;
    vector<blockItem> block_group;
    OptimizeAnalyzer(map<int, string> nametable, symbolTable* globaltable, vector<Quadruple> senman_code);
    int analysis(); //返回减少中间代码的条数
};
#endif // DAGOPETIMIZER_H
