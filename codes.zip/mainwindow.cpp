#include <windows.h>
#include <shellapi.h>
#include "mainwindow.h"
//#include <winbase.h>


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    this->LR1ANA =new LR1(this->ui->control,this->ui->lex_out1,this->ui->lex_out2,this->ui->gra_out);
    this->Lexinputpath=Linpath ;
    this->Grainputpath=Ginpath ;
    this->Lexoutpath  =Loutpath;
    this->Graoutpath  =Goutpath;

    lexisok=false;
    graisok=false;
    outisok=false;
    lexanaok=false;
    graanaok=false;

    this->code_dec = 0;

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pbt_lex_clicked()
{
    if(this->lexisok&&this->graisok&&this->outisok)
    {
        Mess_to_control("[Lex-Analysis] 文件规定如下：\n",this->ui->control, QTmessage_append);
        Mess_to_control("[Lex-Analysis] 词法分析输入文件："+this->Lexinputpath+"\n",this->ui->control , QTmessage_append);
        Mess_to_control("[Lex-Analysis] 词法分析输出文件："+this->Lexoutpath+"\n",this->ui->control , QTmessage_append);

        this->ui->action_lex->setEnabled(false);
        this->ui->action_gra->setEnabled(false);
        this->ui->action_output->setEnabled(false);
        this->ui->control->append("[Lex-Analysis] 词法分析开始……\n");
        this->ui->control->append("[Lex-Analysis] 词法分析结果将会被存储在指定输出路径……\n");
        this->LR1ANA->lex.lex_analyze(this->Lexinputpath.toStdString());
        this->LR1ANA->lex.output_result(this->Lexoutpath.toStdString());

        this->filetoText(this->Lexinputpath,this->ui->lex_out1);
        this->filetoText(this->Lexoutpath,this->ui->lex_out2);

        this->ui->control->append("[Lex-Analysis] 词法分析结束\n");
        this->lexanaok=true;
        this->ui->action_lex->setEnabled(true);
        this->ui->action_gra->setEnabled(true);
        this->ui->action_output->setEnabled(true);
    }
    else
    {
        this->ui->control->append("请先指定路径,指定输入和输出文件\n");
        QMessageBox::warning(this, tr("提示"),
                             tr("请先指定输入和输出路径！\n"),
                             QMessageBox::Cancel);
    }

}


bool MainWindow::Process_circle()
{
    qDebug()<<lexisok<<endl;
    qDebug()<<graisok<<endl;
    qDebug()<<outisok<<endl;
    qDebug()<<lexanaok<<endl;

    Mess_to_control("[Gra-Analysis] 文件规定如下：\n",this->ui->control,QTmessage_append);
    qDebug()<<"here1"<<endl;
    Mess_to_control("[Gra-Analysis] 语法分析输入文件："+this->Grainputpath+"\n",this->ui->control,QTmessage_append);
    qDebug()<<"here2"<<endl;
    Mess_to_control("[Gra-Analysis] 语法分析输出文件："+this->Graoutpath+"\n",this->ui->control , QTmessage_append);
    this->ui->action_lex->setEnabled(false);
    this->ui->action_gra->setEnabled(false);
    this->ui->action_output->setEnabled(false);
    this->ui->control->append("[Gra-Analysis] 语法分析开始……\n");
    this->ui->control->append("[Gra-Analysis] 语法分析结果将会被存储在指定输出路径……\n");
    qDebug()<<"here2"<<endl;

    this->LR1ANA->read_generators(this->Grainputpath.toStdString());
    qDebug()<<"93"<<this->Grainputpath<<endl;
    qDebug()<<"here3"<<endl;
    this->LR1ANA->get_firstset_of_vn();
    qDebug()<<"here4"<<endl;
    this->LR1ANA->init_items();
    qDebug()<<"here5"<<endl;
    this->LR1ANA->getTable();

    this->LR1ANA->printTable(this->Graoutpath.toStdString());

    int ret=this->LR1ANA->grammartree(this->treepath.toStdString(),this->processpath.toStdString(),this->LR1ANA->lex.Result);


    if(ret==0)
    {
        this->LR1ANA->SemanticAnalysis.printQuadruple(this->semanpath.toStdString().c_str());

        QString comm="dot -Tjpg " + this->treepath + " -o " + this->outpath + "/tree.jpg";
        WinExec(comm.toStdString().c_str(),SW_HIDE);
        qDebug()<<comm<<endl;
        QString treejpg = this->outpath + "/tree.jpg";
        QString treefile = treejpg.replace(QString("/"), QString("\\"));        
        qDebug()<<treefile<<endl;

        QEventLoop eventloop;
        QTimer::singleShot(2000, &eventloop, SLOT(quit()));
        eventloop.exec();  //等待2s,生成tree树
        QString com1="rundll32.exe C:\\Windows\\System32\\shimgvw.dll,ImageView_Fullscreen "+treefile;
        WinExec(com1.toStdString().c_str(),SW_NORMAL);

        this->DAGOptimizer = new OptimizeAnalyzer(this->LR1ANA->lex.NameTable, this->LR1ANA->SemanticAnalysis.global_table, this->LR1ANA->SemanticAnalysis.Quadruple_Code);
        this->code_dec =  this->DAGOptimizer->analysis();

        this->MipsCode = new CodeGenerator(this->DAGOptimizer->Optimise_Quadruple,  this->DAGOptimizer->block_group);
        this->MipsCode->GenerateCode();
        this->PrintMipsCode(this->mipscodepath);

    }
    else
    {
        qDebug()<<"ret"<<ret<<endl;

        QMessageBox::warning(this, tr("提示"),
                             tr("ActionGototable错误，归结失败！！\n"),
                             QMessageBox::Cancel);
    }


    this->ui->control->append("[Gra-Analysis] 语法分析结束\n");
    this->ui->control->append("[Sem-Analysis] 语义分析结束，已经转存四元式\n");
    this->graanaok=true;
    return true;
}

void MainWindow::on_pbt_gra_clicked()
{
    if(this->lexisok&&this->graisok&&this->outisok&&this->lexanaok)
    {
        QWaitingDialog *p_wait=new QWaitingDialog(this);
        p_wait->show();
        QFuture<int> fut_syllable=QtConcurrent::run([=]()->int{ return
                    this->Process_circle();}); //异步处理
        while(!fut_syllable.isFinished())
        {
            QApplication::processEvents(QEventLoop::AllEvents, 100);//唤醒主界面
        }
        p_wait->close();
        this->ui->action_lex->setEnabled(true);
        this->ui->action_gra->setEnabled(true);
        this->ui->action_output->setEnabled(true);


        PrintOptimizeCode(this->code_dec);
        filetoText(this->processpath,this->ui->gra_out);
        filetoText(this->semanpath,this->ui->sem_out);
        filetoText(this->mipscodepath,this->ui->mips_out);  //直接输送到窗口
        PrintActive(); //待用活跃信息
        PrintReg();
        QMessageBox::warning(this, tr("提示"),
                             tr("汇编信息生成结束！\n"),
                             QMessageBox::Cancel);
    }
    else
    {
        this->ui->control->append("请检查路径，为了展示语法树，先进行词法分析\n");
        QMessageBox::warning(this, tr("提示"),
                             tr("请检查路径，为了展示语法树，先进行词法分析！\n"),
                             QMessageBox::Cancel);
    }
}


void MainWindow::on_actionIntroduction_triggered()
{
    Form *intro = new Form();
    intro->setAttribute(Qt::WA_DeleteOnClose);
    intro->show();
}


void MainWindow::on_action_lex_triggered()
{
    this->Lexinputpath = QFileDialog :: getOpenFileName(this, tr("Open File"), "/home", tr("Text files (*.txt);;CPP files (*.cpp)"));
    this->lexisok=true;
    if(this->lexisok&&this->graisok&&this->outisok)
    {
        this->ui->pbt_lex->setDisabled(false);//在没有指定路径前，无法进行词法和语法分析
        this->ui->pbt_gra->setDisabled(false);
    }
}


void MainWindow::on_action_gra_triggered()
{
    this->Grainputpath = QFileDialog :: getOpenFileName(this, tr("Open File"), "/home", tr("Text files (*.txt)"));
    this->graisok=true;
    if(this->lexisok&&this->graisok&&this->outisok)
    {
        this->ui->pbt_lex->setDisabled(false);//在没有指定路径前，无法进行词法和语法分析
        this->ui->pbt_gra->setDisabled(false);
    }
}


void MainWindow::on_action_output_triggered()
{
    this->outpath = QFileDialog::getExistingDirectory(this, tr("Open Directory"),
                                                      "",
                                                      QFileDialog::ShowDirsOnly
                                                      | QFileDialog::DontResolveSymlinks);
    this->Lexoutpath=this->outpath+"/"+Loutpath;
    this->Graoutpath=this->outpath+"/"+Goutpath;
    this->treepath=this->outpath+"/"+Treepath;
    this->processpath=this->outpath+"/"+Processpath;
    this->semanpath = this->outpath+"/"+Semansticpath;
    this->mipscodepath = this->outpath+"/"+CodeGenpath;

    qDebug()<<Lexoutpath<<endl;
    qDebug()<<Graoutpath<<endl;
    qDebug()<<treepath<<endl;
    qDebug()<<this->processpath<<endl;
    qDebug()<<this->semanpath<<endl;
    qDebug()<<this->mipscodepath<<endl;

    this->outisok=true;
    if(this->lexisok&&this->graisok&&this->outisok)
    {
        this->ui->pbt_lex->setDisabled(false);//在没有指定路径前，无法进行词法和语法分析
        this->ui->pbt_gra->setDisabled(false);
    }
}

void MainWindow::filetoText(const QString filePath,QTextBrowser * towhere)
{
    stringstream sstr;
    fstream fin;
    fin.open(filePath.toStdString().c_str(),ios::in);
    if(!fin.is_open())
    {
        QString mes="文件"+filePath+"打开失败！\n";
        Mess_to_control("[Open-file] Open-file failed because can't access to it!\n",this->ui->control,QTmessage_append);
        QMessageBox::warning(this, tr("提示"),
                             tr(mes.toStdString().c_str()),
                             QMessageBox::Cancel);
    }
    char ch;
    while (1) {
        fin.get(ch);
        if (fin.eof())
            break;
        sstr << ch;
    }
    fin.close();
    towhere->setText("");
    while (1) {
        char buf[1000];
        memset(buf,'\0',sizeof(buf));
        sstr.getline(buf, 1000, '\n');
        if (buf[0] == '\0')
            break;
        QString str=buf;
        Mess_to_control(str,towhere,QTmessage_append);
        //towhere->append(str);
    }
}

void MainWindow::PrintOptimizeCode(const int dec_line)
{
    QString Optimize_code_num =QString("一共优化了代码的数量是：") + QString(to_string(dec_line).c_str())+QString("条\n\n");
    Mess_to_control(Optimize_code_num,this->ui->DAG_out,QTmessage_clear); //先设置优化数量
    QString Dagcode="";
    int i=0;
    for (auto x: this->DAGOptimizer->Optimise_Quadruple)
    {
//        cout<<Dagcode.toStdString()<<endl;
        Dagcode += QString("(")+QString(to_string(++i).c_str())+QString(")\t")+QString(x.op.c_str())+QString('\t')+QString(x.arg1.c_str())+QString('\t')+QString(x.arg2.c_str())+QString('\t')+QString(x.res.c_str())+QString('\n');
    }

    Mess_to_control(Dagcode,this->ui->DAG_out,QTmessage_append); //后加
}

void MainWindow::PrintActive()
{
    ui->info_out->clearContents();
    ui->info_out->setRowCount(this->MipsCode->MessTableRecord.size());
    for (auto tno = 0; tno < this->MipsCode->MessTableRecord.size(); tno++)
    {
        messageTableItem gencode_process = this->MipsCode->MessTableRecord[tno];

        ui->info_out->setItem(tno,0,new QTableWidgetItem(gencode_process.Gen_Code.op.data()));
        ui->info_out->setItem(tno,1,new QTableWidgetItem(gencode_process.Gen_Code.arg1.data()));
        ui->info_out->setItem(tno,2,new QTableWidgetItem(gencode_process.Gen_Code.arg2.data()));
        ui->info_out->setItem(tno,3,new QTableWidgetItem(gencode_process.Gen_Code.res.data()));

        string mess="";
        if(gencode_process.result_tag.second)
        {
            if(gencode_process.result_tag.first==INT_MAX)
                mess=string("(^,y)");
            else
                mess=string("("+to_string(gencode_process.result_tag.first)+",y)");
        }
        else
            mess=string("(^,^)");
        ui->info_out->setItem(tno,4,new QTableWidgetItem(mess.data()));

        string left="";
        if(gencode_process.arg1_tag.second)
        {
            if(gencode_process.arg1_tag.first==INT_MAX)
                left=string("(^,y)");
            else
                left=string("("+to_string(gencode_process.arg1_tag.first)+",y)");
        }
        else
            left=string("(^,^)");
        ui->info_out->setItem(tno,5,new QTableWidgetItem(left.data()));

        string right="";
        if(gencode_process.arg2_tag.second)
        {
            if(gencode_process.arg2_tag.first==INT_MAX)
                right=string("(^,y)");
            else
                right=string("("+to_string(gencode_process.arg2_tag.first)+",y)");
        }
        else
            right=string("(^,^)");
        ui->info_out->setItem(tno,6,new QTableWidgetItem(right.data()));
    }
    ui->info_out->resizeColumnsToContents();
}


void MainWindow::PrintReg()
{
    ui->reg_out->clearContents();
    ui->reg_out->setRowCount(this->MipsCode->AnalyRecord.size());
    for (auto i=0;i<this->MipsCode->AnalyRecord.size();i++)
    {
        ui->reg_out->setItem(i,0,new QTableWidgetItem(this->MipsCode->AnalyRecord[i].Gen_Code.op.data()));
        ui->reg_out->setItem(i,1,new QTableWidgetItem(this->MipsCode->AnalyRecord[i].Gen_Code.arg1.data()));
        ui->reg_out->setItem(i,2,new QTableWidgetItem(this->MipsCode->AnalyRecord[i].Gen_Code.arg2.data()));
        ui->reg_out->setItem(i,3,new QTableWidgetItem(this->MipsCode->AnalyRecord[i].Gen_Code.res.data()));
        string object_codes="";

        for (auto j = 0; j < this->MipsCode->AnalyRecord[i].object_codes.size(); j++)
        {
            object_codes+=this->MipsCode->AnalyRecord[i].object_codes[j]+(j == this->MipsCode->AnalyRecord[i].object_codes.size()-1? "":"\n");
        }
        ui->reg_out->setItem(i,4,new QTableWidgetItem(object_codes.data()));
        string RVALUE="";
        for (map<string, vector<pair<string, int>>>::iterator it = this->MipsCode->AnalyRecord[i].RVALUE.begin(); it != this->MipsCode->AnalyRecord[i].RVALUE.end(); it++)
        {
            RVALUE+=it->first+": ";
            for (auto k = 0; k < it->second.size(); k++)
            {
                RVALUE+=it->second[k].first+" ";
            }
            map<string, vector<pair<string, int>>>::iterator olditer=it;
            it++;
            RVALUE+=(it==this->MipsCode->AnalyRecord[i].RVALUE.end()? "":"\n");
            it=olditer;
        }
        ui->reg_out->setItem(i,5,new QTableWidgetItem(RVALUE.data()));
        string AVALUE="";
        for (map<string, vector<string>>::iterator it = this->MipsCode->AnalyRecord[i].AVALUE.begin(); it != this->MipsCode->AnalyRecord[i].AVALUE.end(); it++)
        {
            AVALUE+=it->first+": ";
            for (auto k = 0; k < it->second.size(); k++)
            {
                AVALUE+=it->second[k]+" ";
            }
            map<string, vector<string>>::iterator olditer=it;
            it++;
            AVALUE+=(it==this->MipsCode->AnalyRecord[i].AVALUE.end()? "":"\n");
            it=olditer;
        }
        ui->reg_out->setItem(i,6,new QTableWidgetItem(AVALUE.data()));
    }
    ui->reg_out->resizeRowsToContents();
    ui->reg_out->resizeColumnsToContents();
}

void MainWindow::PrintMipsCode(const QString filePath)
{
    ofstream fout(filePath.toStdString().c_str(), ios::out);
    for (auto x : this->MipsCode->MipsCodes)
        fout<<x<<endl;
    fout.close();
}
