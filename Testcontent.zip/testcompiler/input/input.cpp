// #include<stdio.h>
int program(int a,int b,int c)
{
	int i;
	int j;
	i=0; 	
	if(a>(b+c))
	{
		j=a+(b*c+1);
	}
	else
	{
		j=a;  //j==3
	}
	while(i<=100)
	{
		i=i+3; //6,9...99,102 0x66
	}
	return i;
}
int demo(int a)
{
	a=a+2;
	return a*2;  //14
}
void main(void)
{
	int a[2][2];
	a[0][0]=3;
	a[0][1]=a[0][0]+1; //4
	a[1][0]=a[0][1]+1; //5
	a[1][1]=program(a[0][0],a[0][1],demo(a[1][0]));  //102
  // printf("%d,%d,%d.%d",a[0][0],a[0][1],a[1][0],a[1][1]);
	return;
}